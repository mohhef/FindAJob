create definer = user@localhost event remove_temp_password on schedule
    every '1' MINUTE
        starts '2020-08-04 08:47:34'
    on completion preserve
    enable
    do
    DELETE FROM temp_password
        WHERE timestamp < DATE_SUB(NOW(), INTERVAL 1 MINUTE);

